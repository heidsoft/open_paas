# -*- coding: utf-8 -*-
import json

from django import forms

from common.forms import BaseComponentForm
from components.component import Component
from pyVim import connect

from .toolkit import configs


class GetHostList(Component):
    """
    @api {get} /api/c/compapi/hcp/get_host_list/ get_host_list
    @apiName get_host_list
    @apiGroup API-HCP
    @apiVersion 1.0.0
    @apiDescription 查询主机列表

    @apiParam {string} host vmware主机
    @apiParam {string} user vmware用户
    @apiParam {string} pwd vmware密码
    @apiParam {int} port vmware端口
    """

    # 组件所属系统的系统名
    sys_name = configs.SYSTEM_NAME

    # Form处理参数校验
    class Form(BaseComponentForm):
        vmwareHost = forms.CharField(label=u'Vmware主机IP', required=True)
        vmwareUser = forms.CharField(label=u'Vmware用户名', required=True)
        vmwarePwd = forms.CharField(label=u'Vmware密码', required=True)
        vmwarePort = forms.CharField(label=u'Vmware端口', required=True)

        # clean方法返回的数据可通过组件的form_data属性获取
        def clean(self):
            data = self.cleaned_data
            return {
                'ApplicatioNID': data['app_id'],
            }

    # 组件处理入口
    def handle(self):
        # 获取Form clean处理后的数据
        data = self.form_data

        # 设置当前操作者
        data['operator'] = self.current_user.username

        # 请求系统接口
        try:
            # response = self.outgoing.http_client.post(
            #     host=configs.host,
            #     path='/hcp/get_host_list/',
            #     data=json.dumps(data),
            # )

             print 'vmware主机信息.............start'
             print self.Form.vmwareHost
             print 'vmware主机信息.............end'
             service_instance = connect.SmartConnect(host=self.Form.vmwareHost,
                                                user=self.Form.vmwareUser,
                                                pwd=self.Form.vmwarePwd,
                                                port=int(self.Form.vmwarePort))
        except:
            # TODO: 需要删除，仅用于测试的假数据
            response = {
                'code': 0,
                'data': [
                    {
                        'inner_ip': '127.0.0.1',
                        'plat_id': 1,
                        'host_name': 'hello',
                        'maintainer': 'liubin',
                    },
                ]
            }

        # 对结果进行解析
        code = str(response['code'])
        if code == '0':
            result = {
                'result': True,
                'data': response['data'],
            }
        else:
            result = {
                'result': False,
                'message': result['extmsg']
            }

        # 设置组件返回结果，payload为组件实际返回结果
        self.response.payload = result
